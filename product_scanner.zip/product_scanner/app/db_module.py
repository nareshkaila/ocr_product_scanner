"""
db_module.py
------------
Queries MongoDB (provided cluster) for product details.
Falls back to the Open Food Facts public API when the DB has no match.
"""

from __future__ import annotations
import re
import time
import urllib.parse
import urllib.request
import urllib.error
import json
from typing import Optional


# ── MongoDB helper ──────────────────────────────────────────────────────────

MONGO_URI = (
    "mongodb+srv://ingredoai2:BXM6Hc1R57Hkiofy"
    "@cluster0.zimunh9.mongodb.net/"
)

def _get_mongo_client():
    """Lazy import + connect so the app still works without pymongo installed."""
    try:
        from pymongo import MongoClient
        from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
        # Ping to verify connectivity
        client.admin.command("ping")
        return client
    except ImportError:
        return None
    except Exception:
        return None


def _query_mongodb(search_terms: list[str]) -> Optional[dict]:
    """
    Search the MongoDB cluster for any product matching *search_terms*.

    Strategy
    --------
    1. Try exact barcode match on common barcode fields
    2. Try full-text / regex search on product_name / brands / code
    """
    client = _get_mongo_client()
    if client is None:
        return None

    try:
        # List available databases (skip system ones)
        db_names = [d for d in client.list_database_names()
                    if d not in ("admin", "local", "config")]

        for db_name in db_names:
            db = client[db_name]
            for col_name in db.list_collection_names():
                col = db[col_name]

                # 1. Barcode / code match
                for term in search_terms:
                    if term.isdigit():
                        doc = col.find_one({"code": term})
                        if doc:
                            doc["_source"] = f"MongoDB ({db_name}.{col_name})"
                            return _normalise_mongodb_doc(doc)

                # 2. Regex text search
                for term in search_terms:
                    if not term.isdigit() and len(term) >= 3:
                        pattern = re.compile(term, re.IGNORECASE)
                        doc = col.find_one({
                            "$or": [
                                {"product_name": pattern},
                                {"brands": pattern},
                                {"product_name_en": pattern},
                            ]
                        })
                        if doc:
                            doc["_source"] = f"MongoDB ({db_name}.{col_name})"
                            return _normalise_mongodb_doc(doc)
    except Exception:
        pass
    finally:
        client.close()

    return None


def _normalise_mongodb_doc(doc: dict) -> dict:
    """Map raw MongoDB fields to our canonical product dict."""
    def _first(*keys):
        for k in keys:
            v = doc.get(k)
            if v and str(v).strip():
                return str(v).strip()
        return "N/A"

    nutrition = {}
    nutriments = doc.get("nutriments", {})
    if isinstance(nutriments, dict):
        mapping = {
            "Energy (kcal)": ["energy-kcal_100g", "energy_100g"],
            "Fat (g)": ["fat_100g"],
            "Saturated Fat (g)": ["saturated-fat_100g"],
            "Carbohydrates (g)": ["carbohydrates_100g"],
            "Sugars (g)": ["sugars_100g"],
            "Fiber (g)": ["fiber_100g"],
            "Protein (g)": ["proteins_100g"],
            "Salt (g)": ["salt_100g"],
            "Sodium (mg)": ["sodium_100g"],
        }
        for label, keys in mapping.items():
            for k in keys:
                v = nutriments.get(k)
                if v is not None:
                    nutrition[label] = v
                    break

    return {
        "product_name": _first("product_name", "product_name_en", "product_name_fr"),
        "brand": _first("brands", "brand_owner"),
        "categories": _first("categories", "categories_en", "pnns_groups_1"),
        "ingredients": _first("ingredients_text", "ingredients_text_en"),
        "nutrition_facts": nutrition,
        "quantity": _first("quantity"),
        "nutriscore": _first("nutriscore_grade", "nutrition_grade_fr"),
        "ecoscore": _first("ecoscore_grade"),
        "packaging": _first("packaging"),
        "countries": _first("countries", "countries_en"),
        "_source": doc.get("_source", "MongoDB"),
        "_raw": doc,            # kept for debugging
    }


# ── Open Food Facts fallback ────────────────────────────────────────────────

OFF_BASE = "https://world.openfoodfacts.org"


def _query_off_barcode(barcode: str) -> Optional[dict]:
    url = f"{OFF_BASE}/api/v0/product/{barcode}.json"
    return _off_fetch(url)


def _query_off_search(term: str) -> Optional[dict]:
    encoded = urllib.parse.quote_plus(term)
    url = (
        f"{OFF_BASE}/cgi/search.pl"
        f"?search_terms={encoded}&search_simple=1&action=process&json=1&page_size=1"
    )
    return _off_fetch(url, search=True)


def _off_fetch(url: str, search: bool = False) -> Optional[dict]:
    try:
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "ProductScanner/1.0 (educational project)"}
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        if search:
            products = data.get("products", [])
            if not products:
                return None
            product = products[0]
        else:
            if data.get("status") != 1:
                return None
            product = data.get("product", {})

        return _normalise_off_product(product)

    except Exception:
        return None


def _normalise_off_product(p: dict) -> dict:
    def _first(*keys):
        for k in keys:
            v = p.get(k)
            if v and str(v).strip():
                return str(v).strip()
        return "N/A"

    nutrition = {}
    nutriments = p.get("nutriments", {})
    if isinstance(nutriments, dict):
        for label, key in [
            ("Energy (kcal)", "energy-kcal_100g"),
            ("Fat (g)", "fat_100g"),
            ("Saturated Fat (g)", "saturated-fat_100g"),
            ("Carbohydrates (g)", "carbohydrates_100g"),
            ("Sugars (g)", "sugars_100g"),
            ("Fiber (g)", "fiber_100g"),
            ("Protein (g)", "proteins_100g"),
            ("Salt (g)", "salt_100g"),
        ]:
            v = nutriments.get(key)
            if v is not None:
                nutrition[label] = v

    return {
        "product_name": _first("product_name", "product_name_en"),
        "brand": _first("brands"),
        "categories": _first("categories", "categories_en"),
        "ingredients": _first("ingredients_text", "ingredients_text_en"),
        "nutrition_facts": nutrition,
        "quantity": _first("quantity"),
        "nutriscore": _first("nutriscore_grade", "nutrition_grade_fr"),
        "ecoscore": _first("ecoscore_grade"),
        "packaging": _first("packaging"),
        "countries": _first("countries_tags"),
        "_source": "Open Food Facts API",
        "_raw": p,
    }


# ── Public interface ────────────────────────────────────────────────────────

# ── Demo / offline product cache ────────────────────────────────────────────

_DEMO_DB: list[dict] = [
    {
        "barcodes": ["3017620422003"],
        "keywords": ["nutella", "ferrero"],
        "product_name": "Nutella",
        "brand": "Ferrero",
        "categories": "Spreads, Sweet spreads, Hazelnut spreads, Cocoa and hazelnut spreads",
        "ingredients": (
            "Sugar, Palm Oil, Hazelnuts 13%, Skimmed Milk Powder 8.7%, "
            "Fat-Reduced Cocoa 7.4%, Emulsifiers: Lecithins (Soy), "
            "Vanillin: An Artificial Flavour"
        ),
        "quantity": "400g",
        "nutriscore": "e",
        "ecoscore": "c",
        "countries": "France, Germany, Italy, United Kingdom",
        "packaging": "Glass jar, Plastic lid",
        "nutrition_facts": {
            "Energy (kcal)": 539,
            "Fat (g)": 30.9,
            "Saturated Fat (g)": 10.6,
            "Carbohydrates (g)": 57.5,
            "Sugars (g)": 56.3,
            "Protein (g)": 6.3,
            "Salt (g)": 0.107,
        },
    },
    {
        "barcodes": ["5000153001166"],
        "keywords": ["corn flakes", "cornflakes", "kellogg", "kelloggs"],
        "product_name": "Corn Flakes",
        "brand": "Kellogg's",
        "categories": "Breakfast cereals, Ready-to-eat cereals, Corn flakes",
        "ingredients": (
            "Milled Corn 99%, Sugar, Salt, Barley Malt Flavouring. "
            "Vitamins & Minerals: Niacin, Iron, Vitamin B6, Riboflavin, "
            "Thiamin, Folic Acid, Vitamin D, Vitamin B12."
        ),
        "quantity": "500g",
        "nutriscore": "b",
        "ecoscore": "b",
        "countries": "United Kingdom, Germany, France",
        "packaging": "Cardboard box, Plastic bag",
        "nutrition_facts": {
            "Energy (kcal)": 376,
            "Fat (g)": 0.9,
            "Saturated Fat (g)": 0.2,
            "Carbohydrates (g)": 84.0,
            "Sugars (g)": 8.0,
            "Fiber (g)": 3.0,
            "Protein (g)": 7.0,
            "Salt (g)": 1.2,
        },
    },
    {
        "barcodes": ["5449000000996", "5449000131805"],
        "keywords": ["coca-cola", "coca cola", "coke"],
        "product_name": "Coca-Cola Classic",
        "brand": "The Coca-Cola Company",
        "categories": "Beverages, Carbonated drinks, Sodas, Colas",
        "ingredients": (
            "Carbonated Water, Sugar, Colour (Caramel E150d), "
            "Phosphoric Acid, Natural Flavourings Including Caffeine."
        ),
        "quantity": "330ml",
        "nutriscore": "e",
        "ecoscore": "d",
        "countries": "Belgium, Germany, France, USA",
        "packaging": "Aluminium can",
        "nutrition_facts": {
            "Energy (kcal)": 42,
            "Fat (g)": 0,
            "Saturated Fat (g)": 0,
            "Carbohydrates (g)": 10.6,
            "Sugars (g)": 10.6,
            "Protein (g)": 0,
            "Salt (g)": 0,
        },
    },
    {
        "barcodes": ["070221004772"],
        "keywords": ["oreo", "nabisco", "mondelez"],
        "product_name": "Oreo Original",
        "brand": "Nabisco / Mondelēz",
        "categories": "Biscuits and cakes, Sandwich biscuits, Chocolate biscuits",
        "ingredients": (
            "Unbleached Enriched Flour (Wheat Flour, Niacin, Reduced Iron, Thiamine "
            "Mononitrate, Riboflavin, Folic Acid), Sugar, Palm and/or Canola Oil, "
            "Cocoa (processed with alkali), High Fructose Corn Syrup, Leavening "
            "(Baking Soda and/or Calcium Phosphate), Salt, Soy Lecithin, Chocolate, "
            "Artificial Flavour."
        ),
        "quantity": "154g",
        "nutriscore": "e",
        "ecoscore": "c",
        "countries": "USA, Canada, UK",
        "packaging": "Plastic tray, Cardboard sleeve",
        "nutrition_facts": {
            "Energy (kcal)": 480,
            "Fat (g)": 21,
            "Saturated Fat (g)": 6,
            "Carbohydrates (g)": 71,
            "Sugars (g)": 46,
            "Fiber (g)": 2,
            "Protein (g)": 5,
            "Salt (g)": 0.7,
        },
    },
]


def _query_demo_db(search_terms: list[str]) -> Optional[dict]:
    """Match against the built-in demo database (works offline)."""
    for product in _DEMO_DB:
        # Exact barcode match
        for term in search_terms:
            if term in product["barcodes"]:
                out = {k: v for k, v in product.items()
                       if k not in ("barcodes", "keywords")}
                out["_source"] = "Demo DB (offline)"
                return out
        # Keyword match
        for term in search_terms:
            for kw in product["keywords"]:
                if term in kw or kw in term:
                    out = {k: v for k, v in product.items()
                           if k not in ("barcodes", "keywords")}
                    out["_source"] = "Demo DB (offline)"
                    return out
    return None


def lookup_product(search_terms: list[str]) -> dict:
    """
    Attempt to find a product using *search_terms*.

    Resolution order
    ----------------
    1. MongoDB (barcode exact match)
    2. MongoDB (name / brand regex)
    3. Open Food Facts (barcode, if a numeric term exists)
    4. Open Food Facts (text search on first non-numeric term)

    Returns a normalised product dict, or a dict with ``_found: False``.
    """
    if not search_terms:
        return {"_found": False, "reason": "No search terms provided"}

    # --- MongoDB ---
    result = _query_mongodb(search_terms)
    if result:
        result["_found"] = True
        return result

    # --- OFF barcode ---
    for term in search_terms:
        if term.isdigit() and len(term) >= 8:
            result = _query_off_barcode(term)
            if result:
                result["_found"] = True
                return result

    # --- OFF text search ---
    for term in search_terms:
        if not term.isdigit() and len(term) >= 4:
            result = _query_off_search(term)
            if result:
                result["_found"] = True
                return result
            time.sleep(0.3)   # be polite to the public API

    # --- Demo / offline fallback ---
    result = _query_demo_db(search_terms)
    if result:
        result["_found"] = True
        return result

    return {"_found": False, "reason": "Product not found in any data source"}
