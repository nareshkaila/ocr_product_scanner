"""
ocr_module.py
-------------
Handles image-to-text extraction using Tesseract OCR (via pytesseract).
Falls back to basic image pre-processing to improve recognition accuracy.
"""

import re
import os
import pytesseract
from PIL import Image, ImageFilter, ImageEnhance

# ── Optional: set custom Tesseract path if needed ──────────────────────────
# pytesseract.pytesseract.tesseract_cmd = r'/usr/bin/tesseract'


class OCRModule:
    """Extracts and cleans text from product label images."""

    # Common barcode-like numeric patterns (EAN-13, UPC-A, etc.)
    BARCODE_PATTERN = re.compile(r'\b\d{8,14}\b')

    def __init__(self, lang: str = "eng", psm: int = 6):
        """
        Parameters
        ----------
        lang : Tesseract language code  (default 'eng')
        psm  : Tesseract page-segmentation mode (6 = uniform block of text)
        """
        self.lang = lang
        self.psm = psm

    # ── Pre-processing ──────────────────────────────────────────────────────

    def _preprocess(self, image: Image.Image) -> Image.Image:
        """
        Convert to grayscale, sharpen, and boost contrast so Tesseract
        handles noisy / low-res label photos better.
        """
        img = image.convert("L")                          # grayscale
        img = img.filter(ImageFilter.SHARPEN)             # sharpen
        img = ImageEnhance.Contrast(img).enhance(2.0)     # boost contrast
        # Scale up small images for better character recognition
        w, h = img.size
        if w < 1000:
            scale = 1000 / w
            img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
        return img

    # ── Core extraction ─────────────────────────────────────────────────────

    def extract_text(self, image_path: str) -> dict:
        """
        Run Tesseract on *image_path* and return a structured result dict.

        Returns
        -------
        {
          "raw_text": str,          # everything Tesseract found
          "lines":    [str, ...],   # non-empty lines
          "barcodes": [str, ...],   # numeric sequences that look like barcodes
          "confidence": float,      # mean confidence across all words (0-100)
          "error":    str | None
        }
        """
        result = {
            "raw_text": "",
            "lines": [],
            "barcodes": [],
            "confidence": 0.0,
            "error": None,
        }

        if not os.path.isfile(image_path):
            result["error"] = f"File not found: {image_path}"
            return result

        try:
            img = Image.open(image_path)
        except Exception as exc:
            result["error"] = f"Cannot open image: {exc}"
            return result

        img = self._preprocess(img)

        config = f"--oem 3 --psm {self.psm}"

        try:
            # Full text
            raw = pytesseract.image_to_string(img, lang=self.lang, config=config)
            result["raw_text"] = raw

            # Confidence data
            data = pytesseract.image_to_data(
                img, lang=self.lang, config=config,
                output_type=pytesseract.Output.DICT
            )
            confs = [int(c) for c in data["conf"] if str(c).lstrip("-").isdigit() and int(c) >= 0]
            result["confidence"] = round(sum(confs) / len(confs), 1) if confs else 0.0

        except pytesseract.TesseractError as exc:
            result["error"] = f"Tesseract error: {exc}"
            return result

        # Post-process lines
        lines = [ln.strip() for ln in raw.splitlines() if ln.strip()]
        result["lines"] = lines

        # Extract barcode-like numbers
        full = " ".join(lines)
        result["barcodes"] = self.BARCODE_PATTERN.findall(full)

        return result

    # ── Query-term extraction ───────────────────────────────────────────────

    @staticmethod
    def extract_search_terms(ocr_result: dict, max_terms: int = 5) -> list[str]:
        """
        Derive search-friendly terms from OCR output.

        Heuristic: prefer longer tokens that look like product/brand names
        (no purely numeric strings, length >= 3 characters).
        """
        lines = ocr_result.get("lines", [])
        terms: list[str] = []

        # Barcodes are the most precise identifier
        for bc in ocr_result.get("barcodes", []):
            terms.append(bc)

        # Take the first few lines (product names are usually at the top)
        for line in lines[:8]:
            # Strip punctuation, split into tokens
            tokens = re.split(r'[\s,|/\\]+', line)
            for tok in tokens:
                tok_clean = re.sub(r'[^A-Za-z0-9\-]', '', tok)
                if len(tok_clean) >= 3 and not tok_clean.isdigit():
                    terms.append(tok_clean.lower())

        # De-duplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for t in terms:
            if t not in seen:
                seen.add(t)
                unique.append(t)

        return unique[:max_terms]
