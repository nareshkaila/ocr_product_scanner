"""
streamlit_app.py
----------------
Streamlit web interface for the OCR-based Product Information Scanner.

Run with:
    streamlit run app/streamlit_app.py
"""

import sys
import os
import io
import time

# ── Ensure local package imports work ──────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))

import streamlit as st
from PIL import Image

from ocr_module import OCRModule
from db_module import lookup_product

# ── Page config ────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="🔍 Product Label Scanner",
    page_icon="🛒",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
    .product-card {
        background: linear-gradient(135deg, #1e3a5f 0%, #0d2137 100%);
        border-radius: 16px;
        padding: 24px;
        color: white;
        margin-bottom: 16px;
        border: 1px solid #2d5a8e;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    }
    .product-name {
        font-size: 28px;
        font-weight: 800;
        margin-bottom: 4px;
        color: #fff;
    }
    .brand-tag {
        background: #2d5a8e;
        border-radius: 20px;
        padding: 4px 14px;
        font-size: 13px;
        color: #a8d4f5;
        display: inline-block;
        margin-bottom: 12px;
    }
    .section-title {
        color: #6ab0de;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 11px;
        letter-spacing: 1.5px;
        margin: 16px 0 8px 0;
        border-bottom: 1px solid #2d5a8e;
        padding-bottom: 4px;
    }
    .source-badge {
        background: #0b5e2e;
        color: #7eff9e;
        border-radius: 20px;
        padding: 3px 12px;
        font-size: 11px;
        font-weight: 600;
    }
    .nutri-badge {
        display: inline-block;
        padding: 4px 16px;
        border-radius: 20px;
        font-weight: 800;
        font-size: 18px;
        color: white;
        margin-right: 8px;
    }
    .nutri-a { background: #038141; }
    .nutri-b { background: #85bb2f; }
    .nutri-c { background: #fecb02; color: #333; }
    .nutri-d { background: #ee8100; }
    .nutri-e { background: #e63312; }
    .ocr-box {
        background: #0a0a0a;
        border: 1px solid #333;
        border-radius: 10px;
        padding: 14px;
        font-family: monospace;
        font-size: 13px;
        color: #00e676;
        max-height: 220px;
        overflow-y: auto;
        white-space: pre-wrap;
    }
    .conf-bar-outer {
        background: #1a1a2e;
        border-radius: 10px;
        height: 10px;
        margin: 4px 0 12px 0;
        overflow: hidden;
    }
    .conf-bar-inner {
        height: 100%;
        border-radius: 10px;
        background: linear-gradient(90deg, #e63312, #fecb02, #038141);
    }
    .nutrition-table td { padding: 4px 12px; }
    .nutrition-table tr:nth-child(even) { background: rgba(255,255,255,0.05); }
    .not-found-msg {
        background: #2a1a1a;
        border: 1px solid #8b2020;
        border-radius: 10px;
        padding: 18px;
        color: #ff8a80;
        text-align: center;
        font-size: 16px;
    }
</style>
""", unsafe_allow_html=True)


# ── Helpers ────────────────────────────────────────────────────────────────

@st.cache_resource
def get_ocr():
    return OCRModule()


NUTRI_CLASS = {
    "a": "nutri-a", "b": "nutri-b", "c": "nutri-c",
    "d": "nutri-d", "e": "nutri-e",
}

def render_nutriscore(grade: str):
    g = grade.lower().strip()
    cls = NUTRI_CLASS.get(g, "nutri-c")
    return f'<span class="nutri-badge {cls}">{g.upper()}</span>'


def render_product_card(product: dict):
    name = product.get("product_name", "Unknown Product")
    brand = product.get("brand", "N/A")
    categories = product.get("categories", "N/A")
    ingredients = product.get("ingredients", "N/A")
    nutrition = product.get("nutrition_facts", {})
    quantity = product.get("quantity", "N/A")
    nutriscore = product.get("nutriscore", "")
    ecoscore = product.get("ecoscore", "")
    source = product.get("_source", "")

    nutri_html = render_nutriscore(nutriscore) if nutriscore not in ("N/A", "", None) else ""
    eco_html   = render_nutriscore(ecoscore)   if ecoscore   not in ("N/A", "", None) else ""

    nutrition_rows = ""
    for k, v in nutrition.items():
        nutrition_rows += f"<tr><td style='color:#a8d4f5'>{k}</td><td style='color:#fff;font-weight:600'>{v}</td></tr>"

    html = f"""
    <div class="product-card">
        <div class="product-name">{name}</div>
        <span class="brand-tag">🏷️ {brand}</span>
        {"<span class='source-badge'>✅ " + source + "</span>" if source else ""}
        
        <div class="section-title">📦 Basic Info</div>
        <table style="width:100%;color:#cdd5e0">
            <tr><td style="color:#a8d4f5">Quantity</td><td>{quantity}</td></tr>
            <tr><td style="color:#a8d4f5">Categories</td><td>{categories[:120]}{"…" if len(categories)>120 else ""}</td></tr>
        </table>
        
        {"<div class='section-title'>🍏 Scores</div>" + nutri_html + ("Nutri-Score" if nutri_html else "") + "&nbsp;&nbsp;" + eco_html + ("Eco-Score" if eco_html else "") if nutri_html or eco_html else ""}
        
        <div class="section-title">🧪 Ingredients</div>
        <p style="color:#cdd5e0;font-size:13px;line-height:1.6">{ingredients[:600]}{"…" if len(ingredients)>600 else ""}</p>
        
        {"<div class='section-title'>🔢 Nutrition (per 100g)</div><table class='nutrition-table' style='width:100%'>" + nutrition_rows + "</table>" if nutrition_rows else ""}
    </div>
    """
    st.markdown(html, unsafe_allow_html=True)


# ── Sidebar ────────────────────────────────────────────────────────────────

with st.sidebar:
    st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/e/e7/Open_Food_Facts_logo.svg/320px-Open_Food_Facts_logo.svg.png", width=160)
    st.markdown("## ⚙️ Settings")
    psm_mode = st.selectbox(
        "Tesseract PSM Mode",
        options=[3, 4, 6, 11, 12],
        index=2,
        help="Page Segmentation Mode: 6=uniform block, 3=auto, 11=sparse"
    )
    show_raw_ocr = st.checkbox("Show raw OCR output", value=True)
    show_debug   = st.checkbox("Show extracted search terms", value=True)

    st.markdown("---")
    st.markdown("### 📘 About")
    st.markdown("""
    Scans product label images using **Tesseract OCR**, then looks up product details in:
    1. **MongoDB** cluster (ingredoai2)
    2. **Open Food Facts** API (fallback)
    """)


# ── Main UI ────────────────────────────────────────────────────────────────

st.title("🔍 Product Label Scanner")
st.markdown("Upload a product label image to extract information using OCR and database lookup.")

tab_upload, tab_demo = st.tabs(["📤 Upload Image", "🎯 Manual Search"])

# ── Tab 1: Upload ──────────────────────────────────────────────────────────
with tab_upload:
    uploaded = st.file_uploader(
        "Choose a product label image",
        type=["jpg", "jpeg", "png", "bmp", "tiff", "webp"],
        help="Supports JPG, PNG, BMP, TIFF, WEBP"
    )

    if uploaded:
        col_img, col_res = st.columns([1, 1], gap="large")

        with col_img:
            st.markdown("#### 🖼️ Uploaded Image")
            img = Image.open(uploaded)
            st.image(img, use_container_width=True)

        with col_res:
            st.markdown("#### 🔎 OCR Extraction")

            # Save temp file
            tmp_path = f"/tmp/{uploaded.name}"
            with open(tmp_path, "wb") as f:
                f.write(uploaded.getbuffer())

            with st.spinner("Running OCR…"):
                ocr = get_ocr()
                ocr.psm = psm_mode
                t0 = time.time()
                ocr_result = ocr.extract_text(tmp_path)
                elapsed_ocr = time.time() - t0

            if ocr_result.get("error"):
                st.error(f"OCR Error: {ocr_result['error']}")
                st.stop()

            conf = ocr_result["confidence"]
            st.markdown(f"**OCR Confidence:** {conf:.1f}% &nbsp;|&nbsp; ⏱ {elapsed_ocr:.2f}s")
            bar_w = int(conf)
            st.markdown(
                f'<div class="conf-bar-outer"><div class="conf-bar-inner" style="width:{bar_w}%"></div></div>',
                unsafe_allow_html=True
            )

            if ocr_result["barcodes"]:
                st.markdown(f"**Detected barcodes:** `{'`, `'.join(ocr_result['barcodes'])}`")

            if show_raw_ocr:
                with st.expander("📋 Raw OCR Text", expanded=True):
                    st.markdown(
                        f'<div class="ocr-box">{ocr_result["raw_text"] or "(no text detected)"}</div>',
                        unsafe_allow_html=True
                    )

            search_terms = OCRModule.extract_search_terms(ocr_result)

            if show_debug:
                st.markdown(f"**Search terms:** `{', '.join(search_terms) or 'none'}`")

        # ── Lookup ───────────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("#### 📦 Product Details")

        if not search_terms:
            st.warning("No usable text extracted from the image. Try a clearer photo.")
        else:
            with st.spinner("Searching database…"):
                t1 = time.time()
                product = lookup_product(search_terms)
                elapsed_db = time.time() - t1

            if product.get("_found"):
                st.success(f"✅ Product found via **{product['_source']}** in {elapsed_db:.2f}s")
                render_product_card(product)
            else:
                st.markdown(
                    f'<div class="not-found-msg">❌ No matching product found.<br>'
                    f'<small>Searched: {", ".join(search_terms)}</small></div>',
                    unsafe_allow_html=True
                )
                st.info("💡 Tips: Ensure the label is well-lit, in focus, and text is visible. "
                        "Try cropping to just the text area.")


# ── Tab 2: Manual Search ───────────────────────────────────────────────────
with tab_demo:
    st.markdown("#### 🔍 Search by name or barcode")
    col_a, col_b = st.columns([3, 1])
    with col_a:
        manual_query = st.text_input(
            "Enter product name or barcode",
            placeholder="e.g. Nutella, Coca-Cola, 737628064502"
        )
    with col_b:
        search_btn = st.button("Search", type="primary", use_container_width=True)

    if search_btn and manual_query.strip():
        terms = [t.strip().lower() for t in manual_query.split() if t.strip()]
        # if it looks like a barcode add as-is
        if manual_query.strip().isdigit():
            terms = [manual_query.strip()]

        with st.spinner("Searching…"):
            product = lookup_product(terms)

        if product.get("_found"):
            st.success(f"✅ Found via **{product['_source']}**")
            render_product_card(product)
        else:
            st.markdown(
                f'<div class="not-found-msg">❌ No matching product found for "{manual_query}".</div>',
                unsafe_allow_html=True
            )

    st.markdown("---")
    st.markdown("#### 🧪 Try these examples")
    examples = {
        "Nutella (by name)": ["nutella"],
        "Coca-Cola (by name)": ["coca-cola"],
        "Barcode (Oreo)": ["070221004772"],
        "Kellogg's Corn Flakes": ["kelloggs", "corn flakes"],
    }
    cols = st.columns(len(examples))
    for col, (label, terms) in zip(cols, examples.items()):
        if col.button(label, use_container_width=True):
            with st.spinner(f"Looking up {label}…"):
                product = lookup_product(terms)
            if product.get("_found"):
                st.success(f"✅ Found via **{product['_source']}**")
                render_product_card(product)
            else:
                st.warning(f"Not found: {label}")
