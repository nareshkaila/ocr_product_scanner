"""
cli.py
------
Command-line interface for the OCR-based Product Information Scanner.

Usage examples
--------------
    python app/cli.py image.jpg
    python app/cli.py image.jpg --psm 3 --verbose
    python app/cli.py --search "Nutella"
    python app/cli.py --search "070221004772"
"""

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from ocr_module import OCRModule
from db_module import lookup_product

# ── Colour helpers ──────────────────────────────────────────────────────────
RESET  = "\033[0m"
BOLD   = "\033[1m"
CYAN   = "\033[96m"
GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
DIM    = "\033[2m"
WHITE  = "\033[97m"


def cprint(text, colour=WHITE, bold=False, end="\n"):
    prefix = (BOLD if bold else "") + colour
    print(f"{prefix}{text}{RESET}", end=end)


def hr(char="─", width=60, colour=DIM):
    cprint(char * width, colour)


def print_product(product: dict):
    hr("═", 62, CYAN)
    cprint("  PRODUCT DETAILS", CYAN, bold=True)
    hr("═", 62, CYAN)

    def row(label, value, label_col=CYAN, val_col=WHITE):
        print(f"  {label_col}{label:<22}{RESET}{val_col}{value}{RESET}")

    row("Product Name",   product.get("product_name", "N/A"))
    row("Brand",          product.get("brand", "N/A"))
    row("Quantity",       product.get("quantity", "N/A"))
    row("Nutri-Score",    product.get("nutriscore", "N/A").upper())
    row("Eco-Score",      product.get("ecoscore", "N/A").upper())
    row("Countries",      product.get("countries", "N/A")[:70])

    hr()
    cprint("  CATEGORIES", CYAN, bold=True)
    cats = product.get("categories", "N/A")
    for chunk in [cats[i:i+70] for i in range(0, min(len(cats), 280), 70)]:
        cprint(f"    {chunk}", DIM)

    hr()
    cprint("  INGREDIENTS", CYAN, bold=True)
    ingredients = product.get("ingredients", "N/A")
    for chunk in [ingredients[i:i+72] for i in range(0, min(len(ingredients), 600), 72)]:
        cprint(f"    {chunk}", WHITE)
    if len(ingredients) > 600:
        cprint("    … (truncated)", DIM)

    nutrition = product.get("nutrition_facts", {})
    if nutrition:
        hr()
        cprint("  NUTRITION FACTS  (per 100g)", CYAN, bold=True)
        for k, v in nutrition.items():
            row(f"  {k}", str(v))

    hr("─", 62, DIM)
    cprint(f"  Source: {product.get('_source','?')}", GREEN)
    hr("═", 62, CYAN)


def run_scan(image_path: str, psm: int = 6, verbose: bool = False):
    cprint(f"\n📸  Scanning: {image_path}", BOLD + CYAN)
    hr()

    ocr = OCRModule(psm=psm)

    cprint("🔎  Running OCR…", YELLOW, end=" ")
    t0 = time.time()
    result = ocr.extract_text(image_path)
    elapsed = time.time() - t0

    if result.get("error"):
        cprint(f"\n❌  OCR Error: {result['error']}", RED)
        sys.exit(1)

    cprint(f"done ({elapsed:.2f}s, confidence {result['confidence']}%)", GREEN)

    if result["barcodes"]:
        cprint(f"   Barcodes detected: {', '.join(result['barcodes'])}", YELLOW)

    if verbose:
        hr()
        cprint("RAW OCR TEXT:", DIM)
        for line in result["lines"]:
            cprint(f"  {line}", DIM)

    search_terms = OCRModule.extract_search_terms(result)
    cprint(f"\n🔑  Search terms: {search_terms}", WHITE)

    if not search_terms:
        cprint("\n⚠️  No usable text found. Try a clearer image.", YELLOW)
        sys.exit(0)

    cprint("🔍  Looking up product…", YELLOW, end=" ")
    t1 = time.time()
    product = lookup_product(search_terms)
    cprint(f"done ({time.time()-t1:.2f}s)", GREEN)

    if product.get("_found"):
        print_product(product)
    else:
        cprint(f"\n❌  Product not found. ({product.get('reason','')})", RED)
        cprint("    Searched with: " + ", ".join(search_terms), DIM)


def run_search(query: str):
    terms: list[str]
    if query.strip().isdigit():
        terms = [query.strip()]
    else:
        terms = [t.lower() for t in query.split() if len(t) >= 2]

    cprint(f"\n🔍  Searching: {query}", BOLD + CYAN)
    cprint(f"    Terms: {terms}", DIM)

    t = time.time()
    product = lookup_product(terms)
    cprint(f"    Done in {time.time()-t:.2f}s", DIM)

    if product.get("_found"):
        print_product(product)
    else:
        cprint(f"\n❌  Not found: {query}", RED)


def main():
    parser = argparse.ArgumentParser(
        prog="product-scanner",
        description="OCR-based Product Information Scanner"
    )
    parser.add_argument(
        "image", nargs="?",
        help="Path to product label image (JPG, PNG, …)"
    )
    parser.add_argument(
        "--search", "-s", metavar="QUERY",
        help="Skip OCR — search by name or barcode directly"
    )
    parser.add_argument(
        "--psm", type=int, default=6,
        help="Tesseract PSM mode (default: 6)"
    )
    parser.add_argument(
        "--verbose", "-v", action="store_true",
        help="Print all OCR lines"
    )
    parser.add_argument(
        "--json", action="store_true",
        help="Output product details as JSON"
    )

    args = parser.parse_args()

    if args.search:
        if args.json:
            query = args.search
            terms = [query.strip()] if query.strip().isdigit() else [t.lower() for t in query.split()]
            product = lookup_product(terms)
            product.pop("_raw", None)
            print(json.dumps(product, indent=2, default=str))
        else:
            run_search(args.search)

    elif args.image:
        if not os.path.isfile(args.image):
            cprint(f"❌  File not found: {args.image}", RED)
            sys.exit(1)
        if args.json:
            ocr = OCRModule(psm=args.psm)
            result = ocr.extract_text(args.image)
            terms = OCRModule.extract_search_terms(result)
            product = lookup_product(terms)
            product.pop("_raw", None)
            out = {"ocr": result, "product": product}
            print(json.dumps(out, indent=2, default=str))
        else:
            run_scan(args.image, psm=args.psm, verbose=args.verbose)

    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
