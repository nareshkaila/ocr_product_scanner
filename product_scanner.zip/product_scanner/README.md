# 🔍 OCR-Based Product Information Scanner

A modular Python application that uses **Tesseract OCR** to extract text from product label images, then retrieves detailed product information from a **MongoDB database** and the **Open Food Facts API**.

---

## 📌 Table of Contents

1. [Architecture Overview](#architecture)
2. [Setup Instructions](#setup)
3. [Usage](#usage)
4. [Project Structure](#structure)
5. [Approach & Design Decisions](#approach)
6. [Sample Images & Demo](#demo)
7. [Error Handling](#errors)

---

## 🏗️ Architecture Overview <a name="architecture"></a>

```
Product Image
     │
     ▼
┌─────────────┐      Pre-processing      ┌──────────────┐
│  OCRModule  │ ─── (grayscale, sharp, ─▶│  Tesseract   │
│ ocr_module  │      contrast boost)     │  (pytesseract│
└─────────────┘                          └──────────────┘
     │
     │  raw_text, lines, barcodes, confidence
     ▼
┌──────────────────┐
│ extract_search   │  → ['3017620422003', 'ferrero', 'nutella', ...]
│ _terms()         │
└──────────────────┘
     │
     ▼
┌──────────────────────────────────────────────────────────┐
│                    db_module.lookup_product()             │
│                                                          │
│  1. MongoDB Atlas (ingredoai2 cluster)  ─── if connected │
│     • Barcode exact match                                │
│     • Brand / name regex search                          │
│                                                          │
│  2. Open Food Facts API  ─────────────── if network OK   │
│     • GET /api/v0/product/{barcode}.json                 │
│     • GET /cgi/search.pl?search_terms=…                  │
│                                                          │
│  3. Built-in Demo DB  ─────────────────── always offline │
│     • Nutella, Kellogg's, Coca-Cola, Oreo                │
└──────────────────────────────────────────────────────────┘
     │
     ▼
Normalised Product Dict
{ product_name, brand, categories, ingredients,
  nutrition_facts, quantity, nutriscore, ecoscore, … }
     │
     ├─▶  CLI (cli.py)            ── coloured terminal output
     └─▶  Web UI (streamlit_app)  ── interactive browser app
```

**Resolution order:** MongoDB → Open Food Facts → Demo DB  
The system gracefully degrades when network/DB is unavailable.

---

## ⚙️ Setup Instructions <a name="setup"></a>

### 1. System dependencies

```bash
# Ubuntu / Debian
sudo apt-get update && sudo apt-get install -y \
    tesseract-ocr \
    tesseract-ocr-eng \
    libgl1-mesa-glx         # needed by some Pillow builds

# macOS (Homebrew)
brew install tesseract

# Windows
# Download installer from: https://github.com/UB-Mannheim/tesseract/wiki
```

### 2. Python packages

```bash
pip install -r requirements.txt
```

Alternatively, install only what you need:

```bash
pip install pytesseract Pillow pymongo[srv] streamlit
```

### 3. Verify Tesseract

```bash
tesseract --version
# Should print: tesseract 4.x.x or 5.x.x
```

> **Custom path** — If Tesseract is not on `PATH`, uncomment and set the path at the top of `app/ocr_module.py`:
> ```python
> pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
> ```

### 4. Generate sample images (optional)

```bash
python generate_samples.py
# Creates: sample_images/nutella_label.png
#           sample_images/cornflakes_label.png
#           sample_images/cola_label.png
```

---

## 🚀 Usage <a name="usage"></a>

### Streamlit Web App (Recommended)

```bash
streamlit run app/streamlit_app.py
```

Open `http://localhost:8501` in your browser.

**Features:**
- Drag-and-drop image upload
- Real-time OCR confidence meter
- Adjustable Tesseract PSM mode
- One-click example products
- Manual search by name or barcode

### Command-Line Interface

```bash
# Scan an image
python app/cli.py sample_images/nutella_label.png

# Scan with verbose OCR output
python app/cli.py sample_images/nutella_label.png --verbose

# Try different Tesseract PSM mode (3=auto, 6=block, 11=sparse)
python app/cli.py my_label.jpg --psm 11

# Search without an image
python app/cli.py --search "Nutella"
python app/cli.py --search "3017620422003"   # barcode

# Get JSON output (for programmatic use)
python app/cli.py sample_images/nutella_label.png --json
python app/cli.py --search "Coca-Cola" --json
```

### Python API

```python
from app.ocr_module import OCRModule
from app.db_module import lookup_product

# Step 1: Extract text from image
ocr = OCRModule(psm=6)
result = ocr.extract_text("path/to/label.jpg")

print(result["raw_text"])        # full OCR output
print(result["barcodes"])        # e.g. ['3017620422003']
print(result["confidence"])      # e.g. 93.6

# Step 2: Get search terms
terms = OCRModule.extract_search_terms(result)

# Step 3: Look up product
product = lookup_product(terms)

if product["_found"]:
    print(product["product_name"])   # Nutella
    print(product["brand"])          # Ferrero
    print(product["nutrition_facts"]) # {"Fat (g)": 30.9, ...}
```

---

## 📁 Project Structure <a name="structure"></a>

```
product_scanner/
│
├── app/
│   ├── ocr_module.py          # Tesseract OCR + image pre-processing
│   ├── db_module.py           # MongoDB + Open Food Facts + Demo DB
│   ├── streamlit_app.py       # Web interface (Streamlit)
│   └── cli.py                 # Command-line interface
│
├── sample_images/
│   ├── nutella_label.png      # Generated sample: Nutella 400g
│   ├── cornflakes_label.png   # Generated sample: Kellogg's Corn Flakes
│   └── cola_label.png         # Generated sample: Coca-Cola Classic
│
├── screenshots/
│   └── cli_screenshot.png     # Demo output screenshot
│
├── generate_samples.py        # Script to create sample label images
├── generate_screenshot.py     # Script to create demo screenshots
├── requirements.txt
└── README.md
```

---

## 🧠 Approach & Design Decisions <a name="approach"></a>

### OCR Engine: Tesseract via `pytesseract`

**Why Tesseract?**
- Free, open-source, widely supported (Linux/Mac/Windows)
- No API key or network connection required
- High accuracy on printed text (product labels)
- Alternatives: EasyOCR (better on angled text), PaddleOCR (multilingual), Google Vision API (cloud)

**Pre-processing pipeline:**
1. **Grayscale** — removes colour noise, reduces image complexity
2. **Sharpen** — improves edge clarity for character recognition
3. **Contrast boost** (×2.0) — makes text stand out from background
4. **Upscaling** — small images (<1000px wide) are scaled up; Tesseract works best on high-resolution text

**PSM Modes used:**
| PSM | Description | Best for |
|-----|-------------|----------|
| 6 | Uniform block of text | Standard labels (default) |
| 3 | Fully automatic | Complex layouts |
| 11 | Sparse text | Partial/scattered labels |

### Search Term Extraction

1. **Barcodes first** — numeric sequences of 8-14 digits are the most reliable identifier
2. **Top lines** — product names are typically printed largest (top) on labels
3. **Filtering** — pure numbers, single characters, and common words skipped
4. **Deduplication** — order preserved, duplicates removed

### Data Sources

| Source | Query type | Requires network? |
|--------|-----------|-------------------|
| MongoDB Atlas | Exact barcode, brand/name regex | Yes (port 27017) |
| Open Food Facts API | Barcode lookup, text search | Yes (HTTPS) |
| Built-in Demo DB | Barcode + keyword matching | **No** |

The built-in demo DB ensures the application always demonstrates full functionality, even in offline or network-restricted environments.

### MongoDB Integration

```python
# Connection with 5-second timeout
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)

# Search strategy:
# 1. Iterate all user databases (skip admin/local/config)
# 2. For each collection, try barcode match on "code" field
# 3. Then regex match on product_name / brands fields
```

The schema-agnostic approach means the module works with any MongoDB collection that follows Open Food Facts data structure (the most common schema for food product databases).

---

## 🖼️ Sample Images & Demo <a name="demo"></a>

### Sample: Nutella Label

```
📸  Scanning: sample_images/nutella_label.png
🔎  Running OCR… done (1.40s, confidence 93.6%)
   Barcodes detected: 3017620422003
🔑  Search terms: ['3017620422003', 'ferrero', 'hazelnut', 'spread']
🔍  Looking up product… done (1.24s)

══════════════════════════════════════════════════════════════
  PRODUCT DETAILS
══════════════════════════════════════════════════════════════
  Product Name          Nutella
  Brand                 Ferrero
  Quantity              400g
  Nutri-Score           E
  Eco-Score             C
  Countries             France, Germany, Italy, United Kingdom
──────────────────────────────────────────────────────────────
  NUTRITION FACTS  (per 100g)
    Energy (kcal)       539
    Fat (g)             30.9
    Saturated Fat (g)   10.6
    Carbohydrates (g)   57.5
    Sugars (g)          56.3
    Protein (g)         6.3
    Salt (g)            0.107
══════════════════════════════════════════════════════════════
```

**OCR accuracy results:**

| Image | Confidence | Barcode detected | Product found |
|-------|-----------|-----------------|---------------|
| Nutella label | 93.6% | ✅ 3017620422003 | ✅ |
| Kellogg's Corn Flakes | 91.8% | ✅ 5000153001166 | ✅ |
| Coca-Cola Classic | 89.3% | ❌ (OCR read `330mi`) | ✅ (by name) |

---

## 🛡️ Error Handling <a name="errors"></a>

| Scenario | Handling |
|----------|----------|
| Image file not found | Graceful error message, process exits cleanly |
| Tesseract not installed | `TesseractError` caught, user-friendly message |
| MongoDB unreachable | 5s timeout, silently falls through to next source |
| No text extracted | Warning shown, alternative search suggestions given |
| No product matched | "Not found" message with the search terms used |
| API rate limit / timeout | `urllib` timeout (8s), next source attempted |
| Corrupted/unreadable image | `PIL.UnidentifiedImageError` caught and reported |
| Empty barcode list | Falls back to text-based search |

---

## 📦 Dependencies

| Package | Purpose | Version |
|---------|---------|---------|
| `pytesseract` | Python bindings for Tesseract OCR | ≥0.3.13 |
| `Pillow` | Image loading and pre-processing | ≥9.0.0 |
| `pymongo[srv]` | MongoDB Atlas connection | ≥4.0.0 |
| `streamlit` | Web interface | ≥1.28.0 |
| `requests` | HTTP calls to OFF API | ≥2.28.0 |

System: `tesseract-ocr` package (Linux) or Tesseract installer (Win/Mac).

---

## 🔮 Extending the Module

- **EasyOCR drop-in:** Replace `OCRModule.extract_text()` with `easyocr.Reader(['en']).readtext(image_path)` — better for rotated or handwritten text
- **Real barcode scanning:** Add `pyzbar` for actual barcode/QR decoding from images
- **More data sources:** Slot in FoodData Central (USDA), Edamam, or custom MongoDB collections
- **Language support:** Set `lang='fra+eng'` in Tesseract for bilingual labels
- **Caching:** Add `functools.lru_cache` on `lookup_product()` for repeated scans

---

*Built for the Ingredo AI assessment — February 2026*
