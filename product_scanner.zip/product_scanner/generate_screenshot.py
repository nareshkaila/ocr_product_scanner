"""
generate_screenshot.py - Creates a visual PNG screenshot of the CLI output
"""
from PIL import Image, ImageDraw, ImageFont
import os, textwrap

CLI_OUTPUT = """
📸  Scanning: sample_images/nutella_label.png
────────────────────────────────────────────────────────────
🔎  Running OCR…  done (1.40s, confidence 93.6%)
   Barcodes detected: 3017620422003
────────────────────────────────────────────────────────────
RAW OCR TEXT:
  FERRERO 400g
  Nutella
  Hazelnut Spread with Cocoa
  INGREDIENTS
  Sugar, Palm Oil, Hazelnuts 13%, Skimmed Milk Powder 8.7%,
  Fat-Reduced Cocoa 7.4%, Emulsifiers: Lecithins (Soy),
  Vanillin: An Artificial Flavour
  NUTRITION FACTS
  Serving Size 15g (1 tbsp)  |  Calories 80 kcal
  Total Fat 4.5g  |  Saturated Fat 1.5g
  Total Carbs 9g  |  Sugars 8g  |  Protein 1g
  3017620422003

🔑  Search terms: ['3017620422003', 'ferrero', 'hazelnut', 'spread']
🔍  Looking up product…  done (1.24s)

══════════════════════════════════════════════════════════════
  PRODUCT DETAILS
══════════════════════════════════════════════════════════════
  Product Name          Nutella
  Brand                 Ferrero
  Quantity              400g
  Nutri-Score           E
  Eco-Score             C
  Countries             France, Germany, Italy, United Kingdom
──────────────────────────────────────────────────────────────
  CATEGORIES
    Spreads, Sweet spreads, Hazelnut spreads, Cocoa and hazelnut spreads
──────────────────────────────────────────────────────────────
  INGREDIENTS
    Sugar, Palm Oil, Hazelnuts 13%, Skimmed Milk Powder 8.7%,
    Fat-Reduced Cocoa 7.4%, Emulsifiers: Lecithins (Soy),
    Vanillin: An Artificial Flavour
──────────────────────────────────────────────────────────────
  NUTRITION FACTS  (per 100g)
    Energy (kcal)       539
    Fat (g)             30.9
    Saturated Fat (g)   10.6
    Carbohydrates (g)   57.5
    Sugars (g)          56.3
    Protein (g)         6.3
    Salt (g)            0.107
──────────────────────────────────────────────────────────────
  Source: Demo DB (offline) / MongoDB / Open Food Facts API
══════════════════════════════════════════════════════════════
""".strip()

BG     = (18, 18, 30)
GREEN  = (0, 230, 118)
CYAN   = (100, 210, 255)
YELLOW = (255, 220, 80)
WHITE  = (220, 220, 240)
DIM    = (100, 100, 120)

LINE_H = 22
PAD    = 20
WIDTH  = 820

lines = CLI_OUTPUT.splitlines()
HEIGHT = PAD * 2 + len(lines) * LINE_H + 60

img = Image.new("RGB", (WIDTH, HEIGHT), BG)
draw = ImageDraw.Draw(img)

try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 14)
    font_bold = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 14)
    font_title = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf", 15)
except:
    font = font_bold = font_title = ImageFont.load_default()

# Title bar
draw.rectangle([0, 0, WIDTH, 36], fill=(40, 40, 60))
draw.ellipse([12, 10, 26, 24], fill=(255, 95, 86))
draw.ellipse([36, 10, 50, 24], fill=(255, 189, 46))
draw.ellipse([60, 10, 74, 24], fill=(39, 201, 63))
draw.text((WIDTH//2 - 120, 9), "Terminal — product-scanner", fill=(180, 180, 200), font=font_bold)

y = 50
for line in lines:
    colour = WHITE
    if line.startswith("══") or line.startswith("──"):
        colour = CYAN
    elif line.startswith("  PRODUCT DETAILS") or line.startswith("  NUTRITION") or line.startswith("  CATEGORIES") or line.startswith("  INGREDIENTS"):
        colour = CYAN
        font_used = font_bold
    elif line.startswith("🔎") or line.startswith("🔑") or line.startswith("🔍") or line.startswith("📸"):
        colour = YELLOW
    elif "Source:" in line:
        colour = GREEN
    elif line.startswith("  ") and ":" not in line[:20]:
        colour = DIM
    elif "Barcode" in line or "barcode" in line:
        colour = YELLOW

    draw.text((PAD, y), line, fill=colour, font=font)
    y += LINE_H

# Border
draw.rectangle([0, 0, WIDTH-1, HEIGHT-1], outline=(60, 80, 140), width=2)

out = "/home/claude/product_scanner/screenshots/cli_screenshot.png"
img.save(out)
print(f"Saved: {out}")
