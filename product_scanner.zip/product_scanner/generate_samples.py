"""
generate_samples.py
-------------------
Generates synthetic product label images for demo/testing purposes.
Run with:  python generate_samples.py
"""

from PIL import Image, ImageDraw, ImageFont
import os, random, textwrap

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "sample_images")
os.makedirs(OUTPUT_DIR, exist_ok=True)

PRODUCTS = [
    {
        "filename": "nutella_label.png",
        "bg_color": (201, 71, 28),        # Nutella red-brown
        "title_color": (255, 255, 255),
        "accent": (255, 215, 0),
        "name": "Nutella",
        "brand": "Ferrero",
        "barcode": "3017620422003",
        "quantity": "400g",
        "tagline": "Hazelnut Spread with Cocoa",
        "ingredients": (
            "Sugar, Palm Oil, Hazelnuts 13%, Skimmed Milk Powder 8.7%, "
            "Fat-Reduced Cocoa 7.4%, Emulsifiers: Lecithins (Soy), "
            "Vanillin: An Artificial Flavour"
        ),
        "nutrition": [
            ("Serving Size", "15g (1 tbsp)"),
            ("Calories", "80 kcal"),
            ("Total Fat", "4.5g"),
            ("Saturated Fat", "1.5g"),
            ("Total Carbs", "9g"),
            ("Sugars", "8g"),
            ("Protein", "1g"),
        ],
    },
    {
        "filename": "cornflakes_label.png",
        "bg_color": (30, 90, 168),
        "title_color": (255, 215, 0),
        "accent": (255, 255, 255),
        "name": "Corn Flakes",
        "brand": "Kellogg's",
        "barcode": "5000153001166",
        "quantity": "500g",
        "tagline": "The Original & Best",
        "ingredients": (
            "Milled Corn 99%, Sugar, Salt, Barley Malt Flavouring. "
            "Vitamins and Minerals: Niacin, Iron, Vitamin B6, Riboflavin, "
            "Thiamin, Folic Acid, Vitamin D, Vitamin B12."
        ),
        "nutrition": [
            ("Serving Size", "30g + 125ml milk"),
            ("Calories", "113 kcal"),
            ("Total Fat", "0.3g"),
            ("Saturated Fat", "0.1g"),
            ("Total Carbs", "25g"),
            ("Sugars", "3.5g"),
            ("Protein", "2.5g"),
        ],
    },
    {
        "filename": "cola_label.png",
        "bg_color": (196, 18, 18),
        "title_color": (255, 255, 255),
        "accent": (255, 230, 0),
        "name": "Coca-Cola Classic",
        "brand": "The Coca-Cola Company",
        "barcode": "5449000000996",
        "quantity": "330ml",
        "tagline": "Taste the Feeling",
        "ingredients": (
            "Carbonated Water, Sugar, Colour (Caramel E150d), "
            "Phosphoric Acid, Natural Flavourings Including Caffeine."
        ),
        "nutrition": [
            ("Serving Size", "330ml can"),
            ("Calories", "139 kcal"),
            ("Total Fat", "0g"),
            ("Saturated Fat", "0g"),
            ("Total Carbs", "35g"),
            ("Sugars", "35g"),
            ("Protein", "0g"),
        ],
    },
]


def draw_barcode_bars(draw: ImageDraw.Draw, x: int, y: int, code: str,
                      bar_w: int = 3, height: int = 60):
    """Simple visual barcode (not machine-readable, just decorative)."""
    random.seed(code)
    cx = x
    for ch in code:
        n = int(ch) + 1
        for _ in range(n):
            w = random.randint(1, bar_w)
            draw.rectangle([cx, y, cx + w - 1, y + height], fill=(0, 0, 0))
            cx += w + 1
        cx += 2
    # Print digits below
    digit_x = x
    draw.text((x, y + height + 4), code, fill=(0, 0, 0))


def make_label(product: dict):
    W, H = 700, 900
    img = Image.new("RGB", (W, H), color=product["bg_color"])
    draw = ImageDraw.Draw(img)

    # --- Try to load system fonts (fall back to default) ---
    try:
        font_big   = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 52)
        font_med   = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28)
        font_sm    = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 19)
        font_xs    = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16)
        font_label = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
    except Exception:
        font_big = font_med = font_sm = font_xs = font_label = ImageFont.load_default()

    acc = product["accent"]
    tc  = product["title_color"]

    # Brand
    draw.text((40, 30), product["brand"].upper(), fill=acc, font=font_med)

    # Product name (large)
    draw.text((40, 80), product["name"], fill=tc, font=font_big)

    # Tagline
    draw.text((40, 148), product["tagline"], fill=acc, font=font_sm)

    # Divider
    draw.rectangle([40, 190, W - 40, 193], fill=acc)

    # Quantity badge
    draw.rounded_rectangle([W - 150, 25, W - 30, 80], radius=12, fill=acc)
    draw.text((W - 140, 35), product["quantity"], fill=product["bg_color"], font=font_med)

    # --- White content area ---
    draw.rounded_rectangle([30, 205, W - 30, H - 30], radius=16, fill=(250, 250, 250))

    y = 225

    # Ingredients
    draw.text((50, y), "INGREDIENTS", fill=product["bg_color"], font=font_label)
    y += 32
    wrapped = textwrap.wrap(product["ingredients"], width=68)
    for line in wrapped[:6]:
        draw.text((50, y), line, fill=(40, 40, 40), font=font_xs)
        y += 22

    y += 14
    draw.rectangle([50, y, W - 50, y + 2], fill=product["bg_color"])
    y += 14

    # Nutrition table
    draw.text((50, y), "NUTRITION FACTS", fill=product["bg_color"], font=font_label)
    y += 30

    for label, value in product["nutrition"]:
        # Alternate row bg
        row_fill = (235, 240, 255) if product["nutrition"].index((label, value)) % 2 == 0 else (250, 250, 250)
        draw.rectangle([50, y - 4, W - 52, y + 22], fill=row_fill)
        draw.text((58, y), label, fill=(60, 60, 60), font=font_xs)
        draw.text((W - 180, y), value, fill=(20, 20, 20), font=font_xs)
        y += 26

    y += 18
    draw.rectangle([50, y, W - 50, y + 2], fill=product["bg_color"])
    y += 14

    # Barcode area
    if y + 90 < H - 50:
        draw_barcode_bars(draw, 60, y + 6, product["barcode"], bar_w=2, height=50)

    # Save
    path = os.path.join(OUTPUT_DIR, product["filename"])
    img.save(path, "PNG")
    print(f"  ✅  {product['filename']}")
    return path


if __name__ == "__main__":
    print("Generating sample product label images…")
    for p in PRODUCTS:
        make_label(p)
    print(f"\nSaved to: {OUTPUT_DIR}/")
